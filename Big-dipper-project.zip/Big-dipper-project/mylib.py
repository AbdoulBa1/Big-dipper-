import __main__

print(__main__.__file__)